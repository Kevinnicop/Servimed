package swing;

public interface EventLogin {

    public void loginDone();

    public void logOut();
}
